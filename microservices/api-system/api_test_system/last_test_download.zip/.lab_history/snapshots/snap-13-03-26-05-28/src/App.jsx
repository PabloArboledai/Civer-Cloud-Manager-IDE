import React, { useState, useEffect } from 'react';

/**
 * @component AngelGuardian
 * @version 2.5.1-HOTFIX
 * @description Interfaz de seguridad crítica.
 * FIX: Resolución de ReferenceError mediante importación explícita y validación de scope.
 */
export default function AngelGuardian() {
  // Estado local para el pulso del sistema
  const [pulse, setPulse] = useState(true);
  
  // Datos de amenazas sincronizados con el Nexus
  const [threats] = useState([
    { id: '1', origin: '192.168.1.105', status: 'Blocked', severity: 'High' },
    { id: '2', origin: 'Static-IP-NY', status: 'Monitoring', severity: 'Low' },
    { id: '3', origin: 'Encrypted_Node', status: 'Analyzing', severity: 'Medium' },
  ]);

  // Ciclo de vida: Gestión del pulso visual (Heartbeat)
  useEffect(() => {
    const interval = setInterval(() => {
      setPulse(p => !p);
    }, 2000);
    
    return () => clearInterval(interval);
  }, []);

  // Configuración de métricas de rendimiento
  const statsConfig = [
    { label: 'Shield Uptime', val: '99.98%', color: 'text-blue-400', bg: 'bg-blue-400', progress: '90%' },
    { label: 'Active Sessions', val: '1,242', color: 'text-white', bg: 'bg-white', progress: '65%' },
    { label: 'Inbound Blocks', val: '43.1k', color: 'text-red-400', bg: 'bg-red-400', progress: '40%' }
  ];

  return (
    <div className="min-h-screen bg-[#050510] text-slate-300 font-sans selection:bg-blue-500/30 overflow-x-hidden">
      {/* Navegación Superior - Glassmorphism UI */}
      <nav className="border-b border-white/5 bg-black/40 backdrop-blur-xl px-8 py-4 flex justify-between items-center sticky top-0 z-50">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded bg-blue-600 flex items-center justify-center shadow-[0_0_15px_rgba(37,99,235,0.4)]">
            <svg viewBox="0 0 24 24" className="w-5 h-5 text-white" fill="none" stroke="currentColor" strokeWidth="2.5">
              <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" />
            </svg>
          </div>
          <span className="font-bold tracking-tighter text-white text-xl uppercase">
            Angel<span className="text-blue-500">Guardian</span>
          </span>
          <span className="ml-4 px-2 py-0.5 rounded text-[10px] bg-blue-500/10 border border-blue-500/20 text-blue-400 font-mono">
            v2.5.1
          </span>
        </div>
        
        <div className="flex items-center gap-6">
          <div className="hidden md:flex flex-col items-end">
            <span className="text-[10px] text-slate-500 uppercase tracking-widest">Network Status</span>
            <span className="text-xs font-mono text-green-400">Stable // 14ms</span>
          </div>
          <div className={`w-3 h-3 rounded-full transition-all duration-700 ${
            pulse ? 'bg-green-500 shadow-[0_0_12px_#22c55e]' : 'bg-green-900 shadow-none'
          }`}></div>
        </div>
      </nav>

      <main className="p-8 max-w-7xl mx-auto space-y-8 relative z-10">
        {/* Panel de Estadísticas Críticas */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {statsConfig.map((stat, i) => (
            <div key={`stat-${i}`} className="bg-white/[0.02] border border-white/5 p-6 rounded-2xl hover:border-blue-500/30 transition-all group overflow-hidden">
              <p className="text-slate-500 text-sm font-medium mb-1 uppercase tracking-tight">{stat.label}</p>
              <p className={`text-3xl font-bold tracking-tighter ${stat.color}`}>{stat.val}</p>
              <div className="mt-4 h-1 w-full bg-white/5 rounded-full overflow-hidden">
                <div 
                  className={`h-full ${stat.bg} opacity-20 group-hover:opacity-60 transition-all duration-1000`} 
                  style={{ width: stat.progress }}
                ></div>
              </div>
            </div>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Live Security Nexus (Tabla de Amenazas) */}
          <div className="lg:col-span-2 bg-white/[0.02] border border-white/5 rounded-2xl overflow-hidden shadow-2xl">
            <div className="px-6 py-4 border-b border-white/5 flex justify-between items-center bg-white/[0.01]">
              <h2 className="text-sm font-semibold text-white uppercase tracking-wider">Live Security Nexus</h2>
              <button className="text-[10px] text-blue-400 font-mono hover:text-blue-300 transition-colors uppercase">Export Logs</button>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="text-[11px] text-slate-500 font-mono uppercase bg-black/20">
                    <th className="px-6 py-3 font-medium">Source Origin</th>
                    <th className="px-6 py-3 font-medium">Status Flag</th>
                    <th className="px-6 py-3 font-medium text-right">Severity</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/[0.03]">
                  {threats.map((t) => (
                    <tr key={t.id} className="hover:bg-white/[0.02] transition-colors group">
                      <td className="px-6 py-4 font-mono text-xs text-blue-100/70">{t.origin}</td>
                      <td className="px-6 py-4">
                        <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase border ${
                          t.status === 'Blocked' ? 'bg-red-500/10 border-red-500/20 text-red-400' : 'bg-blue-500/10 border-blue-500/20 text-blue-400'
                        }`}>
                          {t.status}
                        </span>
                      </td>
                      <td className={`px-6 py-4 text-right text-xs font-mono font-bold ${
                        t.severity === 'High' ? 'text-red-500' : t.severity === 'Medium' ? 'text-yellow-500' : 'text-green-500'
                      }`}>
                        [{t.severity.toUpperCase()}]
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Panel Lateral - Neural Engine */}
          <div className="space-y-6">
            <div className="bg-gradient-to-br from-blue-600/10 to-transparent border border-blue-500/20 p-6 rounded-2xl relative overflow-hidden">
              <div className="relative z-10">
                <h3 className="text-white text-sm font-bold mb-4 flex items-center gap-2">
                  <svg viewBox="0 0 24 24" className="w-4 h-4 text-blue-400" fill="none" stroke="currentColor" strokeWidth="2">
                    <path d="M13 2L3 14h9l-1 8 10-12h-9l1-8z" />
                  </svg>
                  NEURAL ENGINE
                </h3>
                <div className="space-y-4">
                  <div className="flex justify-between text-xs font-mono">
                    <span>Load Efficiency</span>
                    <span className="text-blue-400">22%</span>
                  </div>
                  <div className="h-2 bg-white/5 rounded-full overflow-hidden">
                    <div className="h-full bg-blue-500 w-[22%] shadow-[0_0_10px_#3b82f6]"></div>
                  </div>
                  <p className="text-[10px] text-slate-500 leading-tight">
                    Intrusive pattern detection is active. Sub-latent monitoring enabled.
                  </p>
                </div>
              </div>
            </div>

            <div className="bg-white/[0.02] border border-white/5 p-6 rounded-2xl">
              <h3 className="text-white text-[10px] font-bold mb-4 uppercase tracking-[0.2em] opacity-50 font-mono">System Controls</h3>
              <div className="grid grid-cols-2 gap-3">
                <button className="py-2 bg-white/5 rounded-lg text-[10px] font-bold hover:bg-white/10 transition-all border border-white/10 uppercase tracking-tighter">Refresh Logs</button>
                <button className="py-2 bg-white/5 rounded-lg text-[10px] font-bold hover:bg-white/10 transition-all border border-white/10 uppercase tracking-tighter">AI Re-Scan</button>
              </div>
            </div>
          </div>
        </div>
      </main>

      {/* Capas Ambientales (Background Layout) */}
      <div className="fixed inset-0 pointer-events-none -z-10 overflow-hidden">
        <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-blue-900/10 blur-[120px] rounded-full"></div>
        <div className="absolute bottom-[-10%] right-[-10%] w-[30%] h-[30%] bg-blue-800/10 blur-[100px] rounded-full"></div>
      </div>
    </div>
  );
}