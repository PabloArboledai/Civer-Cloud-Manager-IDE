
import React from 'react';
export default function AICustomComponent_cxwhjt() {
    return (
        <div className="bg-purple-900/30 border-2 border-dashed border-purple-500 rounded-2xl p-8 my-8 text-center animate-pulse">
            <h2 className="text-2xl font-bold text-white mb-2 underline">Prueba de IA 2...</h2>
            <p className="text-purple-300 italic">Generado dinámicamente por Figma Make AI</p>
        </div>
    );
}
        